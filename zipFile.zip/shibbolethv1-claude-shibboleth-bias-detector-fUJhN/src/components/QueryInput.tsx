'use client';

import { useState, FormEvent } from 'react';
import { Search, Loader2 } from 'lucide-react';

interface QueryInputProps {
  onSubmit: (topic: string) => void;
  isLoading?: boolean;
  placeholder?: string;
  initialValue?: string;
}

export default function QueryInput({
  onSubmit,
  isLoading = false,
  placeholder = 'Enter any topic...',
  initialValue = '',
}: QueryInputProps) {
  const [topic, setTopic] = useState(initialValue);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (topic.trim() && !isLoading) {
      onSubmit(topic.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto">
      <div className="relative">
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder={placeholder}
          disabled={isLoading}
          className="w-full px-6 py-4 bg-zinc-900 border border-zinc-700 rounded-xl text-white placeholder-zinc-500 font-mono text-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all disabled:opacity-50"
          maxLength={500}
        />
        <button
          type="submit"
          disabled={!topic.trim() || isLoading}
          className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-zinc-700 disabled:cursor-not-allowed rounded-lg text-white font-medium flex items-center gap-2 transition-colors"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="hidden sm:inline">Querying...</span>
            </>
          ) : (
            <>
              <Search className="w-5 h-5" />
              <span className="hidden sm:inline">REVEAL</span>
            </>
          )}
        </button>
      </div>
      <p className="text-zinc-500 text-sm mt-2 text-center">
        Force 4 AI models to judge any topic as GOOD or BAD
      </p>
    </form>
  );
}
